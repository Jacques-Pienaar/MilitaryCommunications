﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace DataLayer
{
    class FileHandler
    {
        FileStream stream;
        StreamReader reader;



    }
}
