﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLayer
{
    public class Encryption
    {



        public Encryption()
        {

        }


        public string BinaryToDecodedString(string binaryText, int shift)
        {
            List<Byte> byteList = new List<Byte>();

            for (int i = 0; i < binaryText.Length; i +=8 )
            {
                byteList.Add(Convert.ToByte(binaryText.Substring(i,8),2));
            }

            string returnText = DecodeText(Encoding.ASCII.GetString(byteList.ToArray()),shift);
            return returnText;
        }

        //method that shifts the characters in the text to a specific alphabetic position.
        public static char ShiftChar(char c, int shift)
        {
            if (!char.IsLetter(c))
            {

                return c;
            }

            char d = char.IsUpper(c) ? 'A' : 'a';
            return (char)((((c + shift) - d) % 26) + d);
        }

        //Method to decode encrypted strings
        public static string DecodeText(string text, int shift)
        {
            return Encrypt(text, 26 - shift);

        }

        //method to encrypt strings
        public static string Encrypt(string text, int shift)
        {
            string output = string.Empty;

            foreach (char c in text)
                output += ShiftChar(c, shift);

            return output;
        }






    }
}
