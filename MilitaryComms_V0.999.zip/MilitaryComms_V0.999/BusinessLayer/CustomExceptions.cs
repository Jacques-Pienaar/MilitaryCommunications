﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLayer
{
    class CustomExceptions : Exception
    {
        public CustomExceptions(string message) :base(message)
        {

        }


    }
}
