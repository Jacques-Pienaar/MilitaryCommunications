﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLayer
{
    class Officer
    {
        private string nationalID;
        private string firstName;
        private string lastName;
        private int age;
        private int rank; //ranks range from 1 to 3
        private string password;
        private string username;

        public string NationalID { get => nationalID; set => nationalID = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public int Age { get => age; set => age = value; }
        public int Rank { get => rank; set => rank = value; }
        public string Password { get => password; set => password = value; }
        public string Username { get => username; set => username = value; }

        public Officer(){  }

        public Officer(string nationalID, string firstName, string lastName, int age, int rank, string password, string username)
        {
            this.nationalID = nationalID;
            this.firstName = firstName;
            this.lastName = lastName;
            this.age = age;
            this.rank = rank;
            this.password = password;
            this.username = username;
        }


        //ctor for logging in
        public Officer(string password, string username)
        {
            this.password = password;
            this.username = username;
        }

        //public int Login()
        //{
        //    //List<Officer> officers = GetOfficers();
        //    int result = 0;

        //    foreach (Officer officer in officers)
        //    {
        //        if (this.CompareTo(officer))
        //        {
        //            result = 1;
        //        }
        //    }

        //    return result;
        //}

        public bool CompareTo(object obj)
        {
            Officer officerToCompare = obj as Officer;
            bool result = false;

            if (officerToCompare.username == this.username)
            {
                if (officerToCompare.password == this.password)
                {
                    result = true;
                    this.FirstName = officerToCompare.FirstName;
                    this.LastName = officerToCompare.LastName;
                    this.Age = officerToCompare.Age;
                    this.Rank = officerToCompare.Rank;
                }
            }

            return result;
        }
    }
}
