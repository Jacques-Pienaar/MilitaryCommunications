﻿namespace MilitaryComms_V0._999
{
    partial class frmMilitarycomms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newMailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tcMain = new System.Windows.Forms.TabControl();
            this.tReviewOld = new System.Windows.Forms.TabPage();
            this.btnDecrypt = new System.Windows.Forms.Button();
            this.rtbReviewMail = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbReviewed = new System.Windows.Forms.ListBox();
            this.txtShift = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.tcMain.SuspendLayout();
            this.tReviewOld.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mailToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(656, 24);
            this.menuStrip1.TabIndex = 11;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mailToolStripMenuItem
            // 
            this.mailToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newMailToolStripMenuItem});
            this.mailToolStripMenuItem.Name = "mailToolStripMenuItem";
            this.mailToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.mailToolStripMenuItem.Text = "Mail";
            // 
            // newMailToolStripMenuItem
            // 
            this.newMailToolStripMenuItem.Name = "newMailToolStripMenuItem";
            this.newMailToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.newMailToolStripMenuItem.Text = "New Mail";
            // 
            // tcMain
            // 
            this.tcMain.Controls.Add(this.tReviewOld);
            this.tcMain.Location = new System.Drawing.Point(12, 27);
            this.tcMain.Name = "tcMain";
            this.tcMain.SelectedIndex = 0;
            this.tcMain.Size = new System.Drawing.Size(644, 411);
            this.tcMain.TabIndex = 12;
            // 
            // tReviewOld
            // 
            this.tReviewOld.Controls.Add(this.txtShift);
            this.tReviewOld.Controls.Add(this.btnDecrypt);
            this.tReviewOld.Controls.Add(this.rtbReviewMail);
            this.tReviewOld.Controls.Add(this.label2);
            this.tReviewOld.Controls.Add(this.label1);
            this.tReviewOld.Controls.Add(this.lbReviewed);
            this.tReviewOld.Location = new System.Drawing.Point(4, 22);
            this.tReviewOld.Name = "tReviewOld";
            this.tReviewOld.Padding = new System.Windows.Forms.Padding(3);
            this.tReviewOld.Size = new System.Drawing.Size(636, 385);
            this.tReviewOld.TabIndex = 0;
            this.tReviewOld.Text = "Review Old Mail";
            this.tReviewOld.UseVisualStyleBackColor = true;
            // 
            // btnDecrypt
            // 
            this.btnDecrypt.Location = new System.Drawing.Point(232, 342);
            this.btnDecrypt.Name = "btnDecrypt";
            this.btnDecrypt.Size = new System.Drawing.Size(94, 23);
            this.btnDecrypt.TabIndex = 15;
            this.btnDecrypt.Text = "Decrypt";
            this.btnDecrypt.UseVisualStyleBackColor = true;
            this.btnDecrypt.Click += new System.EventHandler(this.btnDecrypt_Click);
            // 
            // rtbReviewMail
            // 
            this.rtbReviewMail.Location = new System.Drawing.Point(182, 52);
            this.rtbReviewMail.Name = "rtbReviewMail";
            this.rtbReviewMail.Size = new System.Drawing.Size(446, 282);
            this.rtbReviewMail.TabIndex = 14;
            this.rtbReviewMail.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(198, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Subject";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(198, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Sender";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbReviewed
            // 
            this.lbReviewed.FormattingEnabled = true;
            this.lbReviewed.Location = new System.Drawing.Point(6, 11);
            this.lbReviewed.Name = "lbReviewed";
            this.lbReviewed.Size = new System.Drawing.Size(159, 368);
            this.lbReviewed.TabIndex = 11;
            // 
            // txtShift
            // 
            this.txtShift.Location = new System.Drawing.Point(182, 342);
            this.txtShift.Name = "txtShift";
            this.txtShift.Size = new System.Drawing.Size(44, 20);
            this.txtShift.TabIndex = 16;
            // 
            // frmMilitarycomms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(656, 439);
            this.Controls.Add(this.tcMain);
            this.Controls.Add(this.menuStrip1);
            this.Name = "frmMilitarycomms";
            this.Text = "Military communication Centre";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tcMain.ResumeLayout(false);
            this.tReviewOld.ResumeLayout(false);
            this.tReviewOld.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newMailToolStripMenuItem;
        private System.Windows.Forms.TabControl tcMain;
        private System.Windows.Forms.TabPage tReviewOld;
        private System.Windows.Forms.Button btnDecrypt;
        private System.Windows.Forms.RichTextBox rtbReviewMail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lbReviewed;
        private System.Windows.Forms.TextBox txtShift;
    }
}

