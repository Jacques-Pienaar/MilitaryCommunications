﻿using System;
namespace MilitaryCommunications
{
    public class CustomException
    {
        public CustomException(){}
    }
}
